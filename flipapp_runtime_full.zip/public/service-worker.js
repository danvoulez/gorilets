@@ const ASSET_URLS = [
-  '/ui/chat_ui.logline',
-  '/ui/components/button.logline',
+  '/ui/chat_ui.logline',
+  '/ui/whatsapp_ui.logline',
+  '/ui/whatsapp_styles.logline',
+  '/ui/components/button.logline',