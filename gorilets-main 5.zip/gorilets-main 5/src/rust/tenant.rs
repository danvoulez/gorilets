// Model de tenant
