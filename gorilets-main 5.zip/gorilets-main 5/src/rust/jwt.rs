// Chave pública/privada, algoritmos HS256/RS256
