// OpenTelemetry: tracer, exporter OTLP, métricas customizadas
