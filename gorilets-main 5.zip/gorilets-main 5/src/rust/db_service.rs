// Serviço de banco de dados: pool SQLx, transações, migrações
