// Serviço de infraestrutura: client k8s, AWS SDK, alertas Prometheus
