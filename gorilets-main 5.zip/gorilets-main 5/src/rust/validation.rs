// Validações customizadas, esquema YAML/JSON
