// Redis por tenant, TTL, contadores de cotas LLM
