#!/bin/bash
# Deploy script for Minicontratos 2030
kubectl apply -f ../k8s/deployment.yaml
