// Serviço de autenticação: hash/sal de senhas, geração e validação de JWT
