// Funções de timestamp, formatação
