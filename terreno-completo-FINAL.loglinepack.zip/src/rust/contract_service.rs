// Serviço de contratos: validação de YAML, persistência, versionamento
