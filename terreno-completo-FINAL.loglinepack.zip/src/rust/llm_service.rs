// Serviço de LLM: roteamento local/cloud, controle de quotas, monitoramento de custos
