// Model de span
