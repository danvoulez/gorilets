// Enum AppError, Result<T, AppError>, conversão para HttpResponse
