// Configuração do pool Postgres, RLS, migrações automáticas
