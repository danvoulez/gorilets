// Qualquer utilitário comum, ex.: geração de resposta HTML a partir de spans ui.render do backend
