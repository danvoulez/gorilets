# Span Reference

This document describes the span model and its usage in Minicontratos 2030 contracts and backend.
