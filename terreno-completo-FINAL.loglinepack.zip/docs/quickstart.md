# Quickstart

1. Clone the repository
2. Build backend and frontend
3. Run migrations
4. Deploy using provided scripts
