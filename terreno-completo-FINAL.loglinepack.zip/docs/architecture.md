# Minicontratos 2030 Architecture

This document describes the architecture of the Minicontratos 2030 platform, including contracts, backend, frontend, infrastructure, and monitoring components.
